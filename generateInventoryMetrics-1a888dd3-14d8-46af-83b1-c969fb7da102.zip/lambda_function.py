import pandas as pd
import numpy as np
from datetime import datetime
import boto3
import io
from io import StringIO

def lambda_handler(event, context):
    try:
        # Initialize S3 client
        s3_client = boto3.client('s3')
        
        # S3 bucket and file information
        # Replace these with your actual S3 bucket names and file paths
        input_bucket = 'forecast4779'
        output_bucket = 'suppliermaster4779'
        forecast_file = 'Forecast.csv'
        supplier_file = 'Suppliermaster.csv'
        output_file = 'Weekly_Forecast_with_Stock_Levels.csv'

        # Read CSV files from S3
        def read_csv_from_s3(bucket, file_name):
            response = s3_client.get_object(Bucket=bucket, Key=file_name)
            return pd.read_csv(io.BytesIO(response['Body'].read()))

        # Read input files
        try:
            forecast_df = read_csv_from_s3(input_bucket, forecast_file)
            supplier_df = read_csv_from_s3(input_bucket, supplier_file)
        except Exception as e:
            return {
                'statusCode': 400,
                'body': f'Error reading input files: {str(e)}'
            }

        # Convert time_id to datetime in both dataframes
        forecast_df['time_id'] = pd.to_datetime(forecast_df['time_id'])
        supplier_df['time_id'] = pd.to_datetime(supplier_df['time_id'])

        # Create week number columns for forecast data
        forecast_df['week'] = forecast_df['time_id'].dt.isocalendar().week
        forecast_df['year'] = forecast_df['time_id'].dt.isocalendar().year

        # Add week and year to supplier data for joining
        supplier_df['week'] = supplier_df['time_id'].dt.isocalendar().week
        supplier_df['year'] = supplier_df['time_id'].dt.isocalendar().year

        # Calculate weekly forecast sum and std
        weekly_forecast = forecast_df.groupby(['product_id', 'location_id', 'year', 'week']).agg({
            'forecast_value': ['sum', 'std']
        }).reset_index()

        # Flatten the column names
        weekly_forecast.columns = ['product_id', 'location_id', 'year', 'week', 'forecast_sum', 'forecast_std']
        weekly_forecast['forecast_std'] = weekly_forecast['forecast_std'].fillna(0)

        # Calculate weekly maximum ROQ
        weekly_roq = supplier_df.groupby(['product_id', 'location_id', 'year', 'week'])['roq'].max().reset_index()

        # Merge forecast and ROQ data
        final_df = pd.merge(weekly_forecast, weekly_roq, 
                           on=['product_id', 'location_id', 'year', 'week'], 
                           how='left')

        # Calculate Max_Stock and Min_Stock and round up
        final_df['Max_Stock'] = final_df.apply(
            lambda row: np.ceil(max(row['forecast_sum'], row['roq']) + row['forecast_std']), axis=1)
        final_df['Min_Stock'] = final_df.apply(
            lambda row: np.ceil(max(row['forecast_sum'], row['roq'])), axis=1)

        # Function to get the date of Monday for a given year and week
        def get_monday_date(year, week):
            monday = datetime.strptime(f'{year}-W{week:02d}-1', '%Y-W%W-%w')
            return monday.strftime('%Y-%m-%d')

        # Add time_id column
        final_df['time_id'] = final_df.apply(
            lambda row: get_monday_date(int(row['year']), int(row['week'])), axis=1)

        # Convert time_id to datetime for sorting
        final_df['time_id'] = pd.to_datetime(final_df['time_id'])

        # Reorder columns
        column_order = ['product_id', 'location_id', 'time_id', 'year', 'week', 
                       'forecast_sum', 'forecast_std', 'roq', 'Max_Stock', 'Min_Stock']
        final_df = final_df[column_order]

        # Sort the results
        final_df = final_df.sort_values(['product_id', 'location_id', 'time_id'])

        # Convert time_id back to string format
        final_df['time_id'] = final_df['time_id'].dt.strftime('%Y-%m-%d')

        # Convert Max_Stock and Min_Stock to integers
        final_df['Max_Stock'] = final_df['Max_Stock'].astype(int)
        final_df['Min_Stock'] = final_df['Min_Stock'].astype(int)

        # Write the results back to S3
        try:
            csv_buffer = StringIO()
            final_df.to_csv(csv_buffer, index=False)
            s3_client.put_object(
                Bucket=output_bucket,
                Key=output_file,
                Body=csv_buffer.getvalue()
            )
        except Exception as e:
            return {
                'statusCode': 500,
                'body': f'Error writing output file: {str(e)}'
            }

        # Return success response
        return {
            'statusCode': 200,
            'body': f'Successfully processed {len(final_df)} records'
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': f'Error in lambda execution: {str(e)}'
        }
